Program: Lab 01 Phase 01
Created by: Aidan Roth
Date: Fall 2019

What works: Tokenizer class correctly identifies well-formed html tags and their line/character position. Token class correctly outputs each token with its tag name and line/character. All the requirements for phase 1 are satisified.

What doesn't work: The TagParser class, but that's for phase 2.
